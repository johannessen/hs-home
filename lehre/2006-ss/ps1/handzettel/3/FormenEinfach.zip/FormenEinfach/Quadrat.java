/*
 * $Id: Quadrat.java $
 * 2006-05-23
 * by Arne Johannessen
 * based on BlueJ example project "shapes"
 * based on class Square by Michael Kolling, David J. Barnes
 */


import java.awt.*;

/**
 * A square that can be manipulated and that draws itself on a canvas.
 * 
 * @author	Michael Kolling and David J. Barnes
 * @version 1.0  (15 July 2000)
 */

public class Quadrat
{
    private int size;
	private int xPosition;
	private int yPosition;
	private String color;
	private boolean isVisible;

    /**
     * Erstellt ein neues Quadrat in der Standardposition mit der Standardfarbe.
     */
    public Quadrat()
    {
		size = 30;
		xPosition = 60;
		yPosition = 50;
		color = "rot";
		machSichtbar();
    }

	/**
	 * Make this square visible. If it was already visible, do nothing.
	 */
	public void machSichtbar()
	{
		isVisible = true;
		draw();
	}
	
	/**
	 * Make this square invisible. If it was already invisible, do nothing.
	 */
	public void machUnsichtbar()
	{
		erase();
		isVisible = false;
	}
	
    /**
     * Move the square a few pixels to the right.
     */
    public void verschiebeNachRechts()
    {
		verschiebeHorizontal(20);
    }

    /**
     * Move the square a few pixels to the left.
     */
    public void verschiebeNachLinks()
    {
		verschiebeHorizontal(-20);
    }

    /**
     * Move the square a few pixels up.
     */
    public void verschiebeNachOben()
    {
		verschiebeVertikal(-20);
    }

    /**
     * Move the square a few pixels down.
     */
    public void verschiebeNachUnten()
    {
		verschiebeVertikal(20);
    }

    /**
     * Bewegt das Quadrat horizontal um "entfernung" Pixel.
     */
    public void verschiebeHorizontal(int entfernung)
    {
		erase();
		xPosition += entfernung;
		draw();
    }

    /**
     * Bewegt das Quadrat vertikal um "entfernung" Pixel.
     */
    public void verschiebeVertikal(int entfernung)
    {
		erase();
		yPosition += entfernung;
		draw();
    }

    /**
     * Bewegt das Quadrat langsam horizontal um "entfernung" Pixel.
     */
    public void verschiebeLangsamHorizontal(int entfernung)
    {
		int delta;

		if(entfernung < 0) 
		{
			delta = -1;
			entfernung = -entfernung;
		}
		else 
		{
			delta = 1;
		}

		for(int i = 0; i < entfernung; i++)
		{
			xPosition += delta;
			draw();
		}
    }

    /**
     * Bewegt das Quadrat langsam vertikal um "entfernung" Pixel.
     */
    public void verschiebeLangsamVertikal(int entfernung)
    {
		int delta;

		if(entfernung < 0) 
		{
			delta = -1;
			entfernung = -entfernung;
		}
		else 
		{
			delta = 1;
		}

		for(int i = 0; i < entfernung; i++)
		{
			yPosition += delta;
			draw();
		}
    }

    /**
     * Setzt die Kantenlaenge des Quadrats auf die angegebene Groesse
     * in Pixel. Die Kantenlaenge muss >= 0 sein.
     */
    public void aendereGroesse(int neueKantenlaenge)
    {
		erase();
		size = neueKantenlaenge;
		draw();
    }

    /**
     * Aendert die Farbe. Erlaubt sind "rot", "gelb", "blau", "gruen",
	 * "magenta" und "schwarz".
     */
    public void aendereFarbe(String neueFarbe)
    {
		color = neueFarbe;
		draw();
    }

	/*
	 * Draw the square with current specifications on screen.
	 */
	private void draw()
	{
		if(isVisible) {
			Leinwand canvas = Leinwand.holeLeinwand();
			canvas.draw(this, color,
						new Rectangle(xPosition, yPosition, size, size));
			canvas.wait(10);
		}
	}

	/*
	 * Erase the square on screen.
	 */
	private void erase()
	{
		if(isVisible) {
			Leinwand canvas = Leinwand.holeLeinwand();
			canvas.erase(this);
		}
	}
}
