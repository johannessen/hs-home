/*
 * $Id: Dreieck.java $
 * 2006-05-23
 * by Arne Johannessen
 * based on BlueJ example project "shapes"
 * based on class Triangle by Michael Kolling, David J. Barnes
 */


import java.awt.*;

/**
 * A triangle that can be manipulated and that draws itself on a canvas.
 * 
 * @author	Michael Kolling and David J. Barnes
 * @version 1.0  (15 July 2000)
 */

public class Dreieck
{
    private int height;
    private int width;
	private int xPosition;
	private int yPosition;
	private String color;
	private boolean isVisible;

    /**
     * Create a new triangle at default position with default color.
     */
    public Dreieck()
    {
		height = 30;
		width = 40;
		xPosition = 50;
		yPosition = 15;
		color = "gruen";
		machSichtbar();
    }

	/**
	 * Make this triangle visible. If it was already visible, do nothing.
	 */
	public void machSichtbar()
	{
		isVisible = true;
		draw();
	}
	
	/**
	 * Make this triangle invisible. If it was already invisible, do nothing.
	 */
	public void machUnsichtbar()
	{
		erase();
		isVisible = false;
	}
	
    /**
     * Move the triangle a few pixels to the right.
     */
    public void verschiebeNachRechts()
    {
		verschiebeHorizontal(20);
    }

    /**
     * Move the triangle a few pixels to the left.
     */
    public void verschiebeNachLinks()
    {
		verschiebeHorizontal(-20);
    }

    /**
     * Move the triangle a few pixels up.
     */
    public void verschiebeNachOben()
    {
		verschiebeVertikal(-20);
    }

    /**
     * Move the triangle a few pixels down.
     */
    public void verschiebeNachUnten()
    {
		verschiebeVertikal(20);
    }

    /**
     * Bewegt das Dreieck horizontal um "entfernung" Pixel.
     */
    public void verschiebeHorizontal(int entfernung)
    {
		erase();
		xPosition += entfernung;
		draw();
    }

    /**
     * Bewegt das Dreieck vertikal um "entfernung" Pixel.
     */
    public void verschiebeVertikal(int entfernung)
    {
		erase();
		yPosition += entfernung;
		draw();
    }

    /**
     * Bewegt das Dreieck langsam horizontal um "entfernung" Pixel.
     */
    public void verschiebeLangsamHorizontal(int entfernung)
    {
		int delta;

		if(entfernung < 0) 
		{
			delta = -1;
			entfernung = -entfernung;
		}
		else 
		{
			delta = 1;
		}

		for(int i = 0; i < entfernung; i++)
		{
			xPosition += delta;
			draw();
		}
    }

    /**
     * Bewegt das Dreieck langsam vertikal um "entfernung" Pixel.
     */
    public void verschiebeLangsamVertikal(int entfernung)
    {
		int delta;

		if(entfernung < 0) 
		{
			delta = -1;
			entfernung = -entfernung;
		}
		else 
		{
			delta = 1;
		}

		for(int i = 0; i < entfernung; i++)
		{
			yPosition += delta;
			draw();
		}
    }

    /**
     * Setzt die Masse des Dreiecks auf die angegebenen Groessen
     * in Pixel. Die Groessen muessen >= 0 sein.
     */
    public void aendereGroesse(int neueHoehe, int neueBreite)
    {
		erase();
		height = neueHoehe;
		width = neueBreite;
		draw();
    }

    /**
     * Aendert die Farbe. Erlaubt sind "rot", "gelb", "blau", "gruen",
	 * "magenta" und "schwarz".
     */
    public void aendereFarbe(String neueFarbe)
    {
		color = neueFarbe;
		draw();
    }

	/*
	 * Draw the triangle with current specifications on screen.
	 */
	private void draw()
	{
		if(isVisible) {
			Leinwand canvas = Leinwand.holeLeinwand();
			int[] xpoints = { xPosition, xPosition + (width/2), xPosition - (width/2) };
			int[] ypoints = { yPosition, yPosition + height, yPosition + height };
			canvas.draw(this, color, new Polygon(xpoints, ypoints, 3));
			canvas.wait(10);
		}
	}

	/*
	 * Erase the triangle on screen.
	 */
	private void erase()
	{
		if(isVisible) {
			Leinwand canvas = Leinwand.holeLeinwand();
			canvas.erase(this);
		}
	}
}
